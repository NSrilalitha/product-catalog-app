
INSERT INTO PRODUCTS (product_code, brand, color, category, price, size, seller) VALUES
  ('P100', 'HRX', 'white', 'shirt', 650.0, 'XL', 'krishna seller'),
  ('P101', 'Rockstar', 'blue', 'shirt', 890.0, 'L', 'Radha seller');