package com.product.catalog.app.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.product.catalog.app.exception.ProductNotFoundException;
import com.product.catalog.app.model.Product;
import com.product.catalog.app.service.ProductService;

/**
 * This class provides rest end points to search products available for booking.
 * User should be able to search products by SKU i.e., product code, category,
 * size, price, color and by seller name.
 * 
 */
@RestController
@RequestMapping(value="api/v1/products/")
public class ProductController {

	// inject service bean into controller
	@Autowired
	private ProductService productService;
	
	/**
	 * This method returns the products by SKU (product code) given as path variable
	 * 
	 * @param SKU - product code which is passed as path variable
	 * @return ResponseEntity<Product>
	 */
	@RequestMapping(value = "getProducts/sku/{SKU}", method = RequestMethod.GET, 
			produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Product> getProductsBySKU(@PathVariable String SKU) {
		Product product = productService.getProductByProductCode(SKU);
		if(null == product) {
			throw new ProductNotFoundException("There are is products available with given SKU i.e., product code.");
		}
		return new ResponseEntity<Product>(product, HttpStatus.OK);
	}
	
	/**
	 * This method returns the list of products by brand which is given as path variable
	 * 
	 * @param brand - product brand which is passed as path variable
	 * @return ResponseEntity<List<Product>>
	 */
	@RequestMapping(value = "getProducts/brand/{brand}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<List<Product>> getProductsByBrand(@PathVariable String brand) {
		List<Product> products = productService.getProductsByBrand(brand);
		if(products.isEmpty()) {
			throw new ProductNotFoundException("There are no products available with given brand.");
		}
		return new ResponseEntity<List<Product>>(products, HttpStatus.OK);
	}
	
	/**
	 * This method returns the list of products by color which is given as path variable
	 * 
	 * @param color - product color which is passed as path variable
	 * @return ResponseEntity<List<Product>>
	 */
	@RequestMapping(value = "getProducts/color/{color}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<List<Product>> getProductsByColor(@PathVariable String color) {
		List<Product> products = productService.getProductsByColor(color);
		if(products.isEmpty()) {
			throw new ProductNotFoundException("There are no products available with given color.");
		}
		return new ResponseEntity<List<Product>>(products, HttpStatus.OK);
	}
	
	/**
	 * This method returns the list of products by size which is given as path variable
	 * 
	 * @param size - product size which is passed as path variable
	 * @return ResponseEntity<List<Product>>
	 */
	@RequestMapping(value = "getProducts/size/{size}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<List<Product>> getProductsBySize(@PathVariable String size) {
		List<Product> products = productService.getProductsBySize(size);
		if(products.isEmpty()) {
			throw new ProductNotFoundException("There are no products available with given size.");
		}
		return new ResponseEntity<List<Product>>(products, HttpStatus.OK);
	}
	
	/**
	 * This method returns the list of products for which price is less than or
	 * equal to given price which is given as path variable
	 * 
	 * @param price - price which is passed as path variable
	 * @return ResponseEntity<List<Product>>
	 */
	@RequestMapping(value = "getProducts/price/{price}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<List<Product>> getProductsByPrice(@PathVariable Double price) {
		// search for products within the range of given price
		List<Product> products = productService.getProductsByPrice(price);
		if(products.isEmpty()) {
			throw new ProductNotFoundException("There are no products available within given price.");
		}
		return new ResponseEntity<List<Product>>(products, HttpStatus.OK);
	}
	
	/**
	 * This method returns the list of products which sell by given seller 
	 * 
	 * @param seller - seller name which is passed as path variable
	 * @return ResponseEntity<List<Product>>
	 */
	@RequestMapping(value = "getProducts/seller/{seller}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<List<Product>> getProductsBySeller(@PathVariable String seller) {
		// search for products sell by given seller
		List<Product> products = productService.getProductsBySeller(seller);
		if(products.isEmpty()) {
			throw new ProductNotFoundException("There are no products available with given seller.");
		}
		return new ResponseEntity<List<Product>>(products, HttpStatus.OK);
	}
	
	/**
	 * This method returns the number of products which sell by given seller 
	 * 
	 * @param seller - seller name which is passed as path variable
	 * @return ResponseEntity<List<Product>>
	 */
	@RequestMapping(value = "getProducts/seller/{seller}/count", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Integer> getProductsCountBySeller(@PathVariable String seller) {
		// search for products sell by given seller
		List<Product> products = productService.getProductsBySeller(seller);
		if(products.isEmpty()) {
			throw new ProductNotFoundException("There are no products available with given seller.");
		}
		return new ResponseEntity<Integer>(products.size(), HttpStatus.OK);
	}
	
}
