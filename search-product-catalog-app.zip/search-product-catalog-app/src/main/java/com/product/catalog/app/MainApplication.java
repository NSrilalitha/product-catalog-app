package com.product.catalog.app;

import java.util.List;
import java.util.Timer;
import java.util.TimerTask;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.product.catalog.app.model.Product;
import com.product.catalog.app.repository.ProductRepository;
import com.product.catalog.app.utility.CSVToBeanConverter;

/**
 * This class is the entry point for the application. This class is responsible
 * for scheduling the database update for every 8 hours.
 *
 */
@SpringBootApplication
public class MainApplication implements CommandLineRunner {

	private Logger logger = LoggerFactory.getLogger(this.getClass());
	
	@Autowired
	private CSVToBeanConverter csvToBeanConverter;
	
	@Autowired
	private ProductRepository productRepository;
	
	
	public static void main(String[] args) {
		SpringApplication.run(MainApplication.class, args);
	}

	/**
	 * In this method, Timer performs database update based on the data read from
	 * CSV file. For every 8 hours, task will be performed, products details will be
	 * updated in Products table.
	 * 
	 */
	@Override
	public void run(String... args) throws Exception {
		/*
		 * 1. Created Timer to schedule a task which updates the products database
		 * 	  for every 8hrs by taking products details from CSV file.
		 * 2. CSV file contains product details which is available in classpath. 
		 * 3. CSV file will be updated with products based on the new brand/seller.
		 * 4. So for every 8 hrs, this scheduled job will read product details from
		 *    csv file and update the database.
		 */
		TimerTask task = new TimerTask() {
			
			@Override
			public void run() {
				System.out.println("======came inside run method======");
				logger.info("======Timer performing database update======");
				// Read product details from CSV file
				List<Product> products = csvToBeanConverter.getProductsFromCSVFile();
				
				// save the products details read from csv to db for every 8 hours.
				products.forEach(product -> {
					// print details of Products received from csv file
					System.out.println(product);
					logger.info("product retrieved from CSV file is " + product);
					productRepository.save(product);
				});
			}
		};
		Timer myTimer = new Timer();
		// scheduling a timer which repeats for every 8 hours.
		myTimer.schedule(task, 28800000, 28800000);
	}

}
