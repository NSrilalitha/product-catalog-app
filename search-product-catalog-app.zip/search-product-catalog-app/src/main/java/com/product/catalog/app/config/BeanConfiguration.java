package com.product.catalog.app.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.product.catalog.app.utility.CSVToBeanConverter;

@Configuration
public class BeanConfiguration {

	@Bean
	public CSVToBeanConverter getCSVToBeanConvertor() {
		CSVToBeanConverter csvToBeanConvertor = new CSVToBeanConverter();
		return csvToBeanConvertor;
	}
	
 }
