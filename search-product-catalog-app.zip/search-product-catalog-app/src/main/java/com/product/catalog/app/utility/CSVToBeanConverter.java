package com.product.catalog.app.utility;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.opencsv.CSVReader;
import com.opencsv.bean.CsvToBean;
import com.opencsv.bean.HeaderColumnNameTranslateMappingStrategy;
import com.product.catalog.app.model.Product;

/**
 * This class reads products details from CSV file which is located in system
 * and maps the product information to Product class.
 */
public class CSVToBeanConverter {

	private Logger logger = LoggerFactory.getLogger(this.getClass());
	
	/**
	 * This method reads products information from CSV file and map it to Product Object.
	 *
	 * @return productsList - List of Products mapped from CSV file.
	 */
	public List<Product> getProductsFromCSVFile() {
		// Hashmap to map CSV data to Product class attributes.
		Map<String, String> columnMapping = new HashMap<String, String>();
		columnMapping.put("product_code", "productCode");
		columnMapping.put("brand", "brand");
		columnMapping.put("category", "category");
		columnMapping.put("color", "color");
		columnMapping.put("price", "price");
		columnMapping.put("size", "size");
		columnMapping.put("seller", "seller");

		// HeaderColumnNameTranslateMappingStrategy
		// for Product class
		HeaderColumnNameTranslateMappingStrategy<Product> strategy = new HeaderColumnNameTranslateMappingStrategy<Product>();
		strategy.setType(Product.class);
		strategy.setColumnMapping(columnMapping);

		// Read CSV file
		File file;
		CSVReader reader = null;
		try {
			// read csv file from system
			file = new File("C:\\Srilalitha\\products-info\\product-details.csv");
			reader = new CSVReader(new FileReader(file));
		} catch (FileNotFoundException exception) {
			logger.error("CSV file not found " + exception.getMessage());
		}

		// call the parse method of CsvToBean
		CsvToBean<Product> csvToProduct = new CsvToBean<>();
		// pass strategy, csvReader to parse method
		List<Product> productsList = csvToProduct.parse(strategy, reader);
		logger.info("Products retrieved from CSV file : " + productsList);
		return productsList;
	}
	
}
