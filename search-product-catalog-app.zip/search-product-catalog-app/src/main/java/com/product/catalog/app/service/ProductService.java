package com.product.catalog.app.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.product.catalog.app.model.Product;

@Service
public interface ProductService {

	public List<Product> getProductsByBrand(String brand);
	
	public List<Product> getProductsByPrice(Double price);
	
	public List<Product> getProductsByColor(String color);
	
	public List<Product> getProductsBySize(String size);
	
	public Product getProductByProductCode(String productCode);
	
	public List<Product> getProductsBySeller(String seller);
	
}
