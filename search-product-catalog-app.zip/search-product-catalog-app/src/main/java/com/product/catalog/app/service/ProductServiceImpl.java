package com.product.catalog.app.service;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.product.catalog.app.model.Product;
import com.product.catalog.app.repository.ProductRepository;

/**
 * User should be able to view products. User can search products by product
 * code (SKU), brand, price, color, size and by seller name. This service class
 * invokes Repository to retrieve products list.
 * 
 */
@Service
@Transactional(propagation=Propagation.SUPPORTS, readOnly=true)
public class ProductServiceImpl implements ProductService {

	private Logger logger = LoggerFactory.getLogger(this.getClass());
	
	@Autowired
	private ProductRepository productRepository;
	
	@Override
	public List<Product> getProductsByBrand(String brand) {
		List<Product> products = productRepository.findByBrand(brand);
		if (products.isEmpty()) {
			logger.info("Products are not available with mentioned brand");
		}
		return products;
	}

	@Override
	public List<Product> getProductsByPrice(Double price) {
		List<Product> products = productRepository.getProductsByPrice(price);
		if (products.isEmpty()) {
			logger.info("Products are not available within given price");
		}
		return products;
	}

	@Override
	public List<Product> getProductsByColor(String color) {
		List<Product> products = productRepository.findByColor(color);
		if (products.isEmpty()) {
			logger.info("Products are not available with given color");
		}
		return products;
	}

	@Override
	public List<Product> getProductsBySize(String size) {
		List<Product> products = productRepository.findBySize(size);
		if (products.isEmpty()) {
			logger.info("Products are not available with given size");
		}
		return products;
	}

	@Override
	public Product getProductByProductCode(String productCode) {
		Product product = productRepository.findById(productCode).get();
		if (null == product) {
			logger.info("There is no product available with given SKU");
		}
		return product;
	}

	@Override
	public List<Product> getProductsBySeller(String seller) {
		List<Product> products = productRepository.findBySeller(seller);
		if (products.isEmpty()) {
			logger.info("Products are not available with given seller name");
		}
		return products;
	}

}
