package com.product.catalog.app.controller;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.SpringBootTest.WebEnvironment;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.boot.web.server.LocalServerPort;
import org.springframework.http.ResponseEntity;

import com.product.catalog.app.model.Product;

@SpringBootTest(webEnvironment = WebEnvironment.RANDOM_PORT)
public class ProductControllerTest {
	
	// binding above RANDOM_PORT
    @LocalServerPort
    private int port;
	
    @Autowired
    private TestRestTemplate restTemplate;
    
    @Test
    public void testGetProductsBySKU() {
    	String url = "http://localhost:" + port + "/api/v1/products/getProducts/sku/P100";
    	ResponseEntity<Product> response = restTemplate.getForEntity(url, Product.class);
    	Product product1 = new Product();
		product1.setProductCode("P100");
		product1.setBrand("HRX");
		product1.setColor("white");
		product1.setPrice(650.0);
		product1.setCategory("shirt");
		product1.setSeller("krishna seller");
		product1.setSize("XL");
		assertEquals(product1, response.getBody());
    }
    
    @Test
    public void testGetProductsByBrand() {
    	String url = "http://localhost:" + port + "/api/v1/products/getProducts/brand/HRX";
    	ResponseEntity<Product[]> response = restTemplate.getForEntity(url, Product[].class);
    	List<Product> products = Arrays.asList(response.getBody());
		assertEquals(getProducts(), products);
    }
    
    @Test
    public void testGetProductsByPrice() {
    	String url = "http://localhost:" + port + "/api/v1/products/getProducts/price/1000";
    	ResponseEntity<Product[]> response = restTemplate.getForEntity(url, Product[].class);
    	List<Product> products = Arrays.asList(response.getBody());
    	List<Product> expectedProducts = new ArrayList<Product>();
    	Product product1 = new Product();
		product1.setProductCode("P100");
		product1.setBrand("HRX");
		product1.setColor("white");
		product1.setPrice(650.0);
		product1.setCategory("shirt");
		product1.setSeller("krishna seller");
		product1.setSize("XL");
		expectedProducts.add(product1);
		
		Product product2 = new Product();
		product2.setProductCode("P101");
		product2.setBrand("Rockstar");
		product2.setColor("blue");
		product2.setPrice(890.0);
		product2.setCategory("shirt");
		product2.setSeller("Radha seller");
		product2.setSize("L"); 
		expectedProducts.add(product2);
		assertEquals(expectedProducts, products);
    }
    
    @Test
    public void testGetProductsByColor() {
    	String url = "http://localhost:" + port + "/api/v1/products/getProducts/color/white";
    	ResponseEntity<Product[]> response = restTemplate.getForEntity(url, Product[].class);
    	List<Product> products = Arrays.asList(response.getBody());
		assertEquals(getProducts(), products);
    }

    @Test
    public void testGetProductsBySize() {
    	String url = "http://localhost:" + port + "/api/v1/products/getProducts/size/XL";
    	ResponseEntity<Product[]> response = restTemplate.getForEntity(url, Product[].class);
    	List<Product> products = Arrays.asList(response.getBody());
		assertEquals(getProducts(), products);
    }
    
    @Test
    public void testGetProductsBySeller() {
    	String url = "http://localhost:" + port + "/api/v1/products/getProducts/seller/krishna seller";
    	ResponseEntity<Product[]> response = restTemplate.getForEntity(url, Product[].class);
    	List<Product> products = Arrays.asList(response.getBody());
		assertEquals(getProducts(), products);
    }

	private List<Product> getProducts() {
		List<Product> expectedProducts = new ArrayList<Product>();
		Product product1 = new Product();
		product1.setProductCode("P100");
		product1.setBrand("HRX");
		product1.setColor("white");
		product1.setPrice(650.0);
		product1.setCategory("shirt");
		product1.setSeller("krishna seller");
		product1.setSize("XL");
		expectedProducts.add(product1);
		return expectedProducts;
	}
    
}
