package com.product.catalog.app.service;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.product.catalog.app.model.Product;

/**
 * This class is to test ProductServiceImpl class.
 */
@SpringBootTest
public class ProductServiceImplTest {

	@Autowired
	private ProductService productService;
	
	@Test
	public void testGetProductsByBrand() {
		List<Product> hrxProducts = new ArrayList<>();
		Product product1 = new Product();
		product1.setProductCode("P100");
		product1.setBrand("HRX");
		product1.setColor("white");
		product1.setPrice(650.0);
		product1.setCategory("shirt");
		product1.setSeller("krishna seller");
		product1.setSize("XL");
		hrxProducts.add(product1);
		
		List<Product> rockstarProducts = new ArrayList<>();
		Product product = new Product();
		product.setProductCode("P101");
		product.setBrand("Rockstar");
		product.setColor("blue");
		product.setPrice(890.0);
		product.setCategory("shirt");
		product.setSeller("Radha seller");
		product.setSize("L"); 
		rockstarProducts.add(product);
		
		assertEquals(hrxProducts, productService.getProductsByBrand("HRX"));
		assertEquals(rockstarProducts, productService.getProductsByBrand("Rockstar"));
	}
	
	@Test
	public void testGetProductByProductCode() {
		Product product = new Product();
		product.setProductCode("P101");
		product.setBrand("Rockstar");
		product.setColor("blue");
		product.setPrice(890.0);
		product.setCategory("shirt");
		product.setSeller("Radha seller");
		product.setSize("L"); 	
		assertEquals(product, productService.getProductByProductCode("P101"));
	}
	
	@Test
	public void testGetProductByPrice() {
		List<Product> products = new ArrayList<Product>();
		Product product1 = new Product();
		product1.setProductCode("P100");
		product1.setBrand("HRX");
		product1.setColor("white");
		product1.setPrice(650.0);
		product1.setCategory("shirt");
		product1.setSeller("krishna seller");
		product1.setSize("XL");
		products.add(product1);
		
		Product product2 = new Product();
		product2.setProductCode("P101");
		product2.setBrand("Rockstar");
		product2.setColor("blue");
		product2.setPrice(890.0);
		product2.setCategory("shirt");
		product2.setSeller("Radha seller");
		product2.setSize("L"); 
		products.add(product2);
		
		assertEquals(products, productService.getProductsByPrice(1000.0));
	}
	
	@Test
	public void testGetProductByColor() {
		List<Product> products = new ArrayList<>();
		Product product = getProduct(); 	
		products.add(product);
		assertEquals(products, productService.getProductsByColor("blue"));
	}
	
	@Test
	public void testGetProductBySize() {
		List<Product> products = new ArrayList<>();
		Product product = getProduct(); 	
		products.add(product);
		assertEquals(products, productService.getProductsBySize("L"));
	}
	
	@Test
	public void testGetProductBySeller() {
		List<Product> products = new ArrayList<>();
		Product product = getProduct(); 	
		products.add(product);
		assertEquals(products, productService.getProductsBySeller("Radha seller"));
	}

	private Product getProduct() {
		Product product = new Product();
		product.setProductCode("P101");
		product.setBrand("Rockstar");
		product.setColor("blue");
		product.setPrice(890.0);
		product.setCategory("shirt");
		product.setSeller("Radha seller");
		product.setSize("L"); 	
		return product;
	}
	
}
